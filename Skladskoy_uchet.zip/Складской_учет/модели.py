from abc import ABC, abstractmethod


class BaseEntity(ABC):
    @abstractmethod
    def get_id(self):
        raise NotImplementedError


class Product(BaseEntity):
    def __init__(self, product_id, name, category, quantity, price):
        self._product_id = int(product_id)
        self.name = name
        self.category = category
        self.quantity = quantity
        self.price = price

    @property
    def product_id(self):
        return self._product_id

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, value):
        value = str(value).strip()
        if not value:
            raise ValueError("Название товара не может быть пустым")
        self._name = value

    @property
    def category(self):
        return self._category

    @category.setter
    def category(self, value):
        value = str(value).strip()
        if not value:
            raise ValueError("Категория не может быть пустой")
        self._category = value

    @property
    def quantity(self):
        return self._quantity

    @quantity.setter
    def quantity(self, value):
        value = int(value)
        if value < 0:
            raise ValueError("Количество не может быть отрицательным")
        self._quantity = value

    @property
    def price(self):
        return self._price

    @price.setter
    def price(self, value):
        value = float(value)
        if value < 0:
            raise ValueError("Цена не может быть отрицательной")
        self._price = value

    def get_id(self):
        return self.product_id

    def __eq__(self, other):
        if not isinstance(other, Product):
            return NotImplemented
        return self.product_id == other.product_id

    def __lt__(self, other):
        if not isinstance(other, Product):
            return NotImplemented
        return self.name.casefold() < other.name.casefold()

    def __str__(self):
        return f"{self.name} ({self.category})"

    def __repr__(self):
        return (f"Product({self.product_id}, {self.name!r}, {self.category!r}, "
                f"{self.quantity}, {self.price})")

    def to_line(self):
        return "|".join((str(self.product_id), self.name, self.category,
                         str(self.quantity), str(self.price)))

    @classmethod
    def from_line(cls, line):
        parts = line.rstrip("\n").split("|")
        if len(parts) != 5:
            raise ValueError("Некорректная строка товара")
        return cls(parts[0], parts[1], parts[2], parts[3], parts[4])

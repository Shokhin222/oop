from datetime import datetime
from pathlib import Path


class SessionReport:
    def __init__(self, username="UserName", report_file="отчет_работы.txt"):
        self.username = username
        self.report_file = Path(report_file)
        self.time_in = datetime.now()
        self.time_out = None

    def close(self):
        self.time_out = datetime.now()
        new_file = not self.report_file.exists()
        with self.report_file.open("a", encoding="utf-8") as file:
            if new_file:
                file.write("+---------------------------------------------------------------+\n")
                file.write("| login    | time_in             | time_out            |\n")
                file.write("|----------|---------------------|---------------------|\n")
            file.write(
                f"| {self.username:<8} | {self.time_in.strftime('%d.%m.%Y %H:%M:%S'):<19} "
                f"| {self.time_out.strftime('%d.%m.%Y %H:%M:%S'):<19} |\n"
            )
            file.write("+---------------------------------------------------------------+\n")

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QKeySequence, QShortcut
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QComboBox, QSpinBox, QDoubleSpinBox, QPushButton, QTableWidget,
    QTableWidgetItem, QMessageBox, QHeaderView, QAbstractItemView
)

from склад import Inventory
from отчет import SessionReport


class ProductTable(QTableWidget):
    def __init__(self):
        super().__init__(0, 5)
        self.setHorizontalHeaderLabels(["ID", "Название", "Категория", "Количество", "Цена"])
        self.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.setAlternatingRowColors(True)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Delete:
            self.parentWidget().parentWidget().delete_selected()
            return
        super().keyPressEvent(event)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Складской учёт")
        self.resize(900, 600)
        self.inventory = Inventory()
        self.report = SessionReport()
        self._build_ui()
        self.refresh_table()
        QShortcut(QKeySequence("Ctrl+F"), self, activated=self.search_field.setFocus)
        QShortcut(QKeySequence("Ctrl+S"), self, activated=self.save_inventory)

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)

        heading = QLabel("Складской учёт")
        heading.setAlignment(Qt.AlignmentFlag.AlignCenter)
        heading.setStyleSheet("font-size: 22px; font-weight: bold; padding: 8px;")
        root.addWidget(heading)

        search_row = QHBoxLayout()
        self.search_field = QLineEdit()
        self.search_field.setPlaceholderText("Поиск по названию, категории или ID")
        self.search_field.textChanged.connect(self.refresh_table)
        search_row.addWidget(self.search_field)
        clear_search = QPushButton("Сбросить поиск")
        clear_search.clicked.connect(self.search_field.clear)
        search_row.addWidget(clear_search)
        root.addLayout(search_row)

        self.table = ProductTable()
        root.addWidget(self.table)

        form = QHBoxLayout()
        self.name_field = QLineEdit()
        self.name_field.setPlaceholderText("Название")
        self.category_box = QComboBox()
        self.category_box.setEditable(True)
        self.category_box.addItems(["Периферия", "Электроника", "Кабели", "Аудио", "Носители"])
        self.quantity_box = QSpinBox()
        self.quantity_box.setRange(0, 1_000_000)
        self.quantity_box.setPrefix("Кол-во: ")
        self.price_box = QDoubleSpinBox()
        self.price_box.setRange(0, 1_000_000_000)
        self.price_box.setDecimals(2)
        self.price_box.setPrefix("Цена: ")
        for widget in (self.name_field, self.category_box, self.quantity_box, self.price_box):
            form.addWidget(widget)
        root.addLayout(form)

        buttons = QHBoxLayout()
        actions = [
            ("Добавить товар", self.add_product),
            ("+1 шт.", lambda: self.change_quantity(1)),
            ("-1 шт.", lambda: self.change_quantity(-1)),
            ("Удалить", self.delete_selected),
            ("Сохранить", self.save_inventory),
        ]
        for title, callback in actions:
            button = QPushButton(title)
            button.clicked.connect(callback)
            buttons.addWidget(button)
        root.addLayout(buttons)

        self.status = QLabel()
        root.addWidget(self.status)

    def refresh_table(self):
        products = self.inventory.find(self.search_field.text())
        self.table.setRowCount(len(products))
        for row, product in enumerate(products):
            values = [product.product_id, product.name, product.category,
                      product.quantity, f"{product.price:.2f}"]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if column in (0, 3, 4):
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.table.setItem(row, column, item)
        self.status.setText(
            f"Позиций: {len(self.inventory.products)} | "
            f"Всего единиц: {self.inventory.total_units()} | "
            f"Стоимость остатков: {self.inventory.total_value():.2f}"
        )

    def selected_product_id(self):
        row = self.table.currentRow()
        if row < 0:
            return None
        return int(self.table.item(row, 0).text())

    def add_product(self):
        try:
            self.inventory.add(
                self.name_field.text(),
                self.category_box.currentText(),
                self.quantity_box.value(),
                self.price_box.value()
            )
            self.name_field.clear()
            self.quantity_box.setValue(0)
            self.price_box.setValue(0)
            self.refresh_table()
        except (ValueError, OSError) as error:
            QMessageBox.warning(self, "Не удалось добавить товар", str(error))

    def change_quantity(self, delta):
        product_id = self.selected_product_id()
        if product_id is None:
            QMessageBox.information(self, "Склад", "Сначала выберите товар в таблице.")
            return
        try:
            self.inventory.change_quantity(product_id, delta)
            self.refresh_table()
        except (ValueError, OSError, KeyError) as error:
            QMessageBox.warning(self, "Не удалось изменить количество", str(error))

    def delete_selected(self):
        product_id = self.selected_product_id()
        if product_id is None:
            QMessageBox.information(self, "Склад", "Сначала выберите товар в таблице.")
            return
        answer = QMessageBox.question(self, "Удаление", "Удалить выбранный товар?")
        if answer == QMessageBox.StandardButton.Yes:
            try:
                self.inventory.delete(product_id)
                self.refresh_table()
            except (OSError, KeyError) as error:
                QMessageBox.warning(self, "Не удалось удалить товар", str(error))

    def save_inventory(self):
        try:
            self.inventory.save()
            self.status.setText("Данные сохранены. " + self.status.text())
        except OSError as error:
            QMessageBox.warning(self, "Ошибка сохранения", str(error))

    def closeEvent(self, event):
        try:
            self.inventory.save()
            self.report.close()
        except OSError as error:
            QMessageBox.critical(self, "Ошибка сохранения", str(error))
            event.ignore()
            return
        event.accept()

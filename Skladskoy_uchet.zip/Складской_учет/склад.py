from pathlib import Path

from коллекция import CustomMap
from модели import Product


class Inventory:
    def __init__(self, data_file="товары.txt"):
        self.data_file = Path(data_file)
        self.products = CustomMap()
        self.load()

    def load(self):
        if not self.data_file.exists():
            self._add_examples()
            self.save()
            return
        loaded = CustomMap()
        try:
            for line in self.data_file.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    product = Product.from_line(line)
                    loaded[product.product_id] = product
            self.products = loaded
        except (ValueError, OSError):
            self.products = loaded

    def save(self):
        lines = [product.to_line() for product in self.all_products()]
        self.data_file.write_text("\n".join(lines) + ("\n" if lines else ""),
                                  encoding="utf-8")

    def _add_examples(self):
        examples = [
            Product(1, "Клавиатура", "Периферия", 12, 1590),
            Product(2, "Мышь", "Периферия", 18, 890),
            Product(3, "Монитор", "Электроника", 7, 12990),
            Product(4, "USB-кабель", "Кабели", 25, 250),
            Product(5, "Наушники", "Аудио", 9, 2490),
            Product(6, "Веб-камера", "Электроника", 5, 3190),
            Product(7, "Флеш-накопитель", "Носители", 20, 650),
            Product(8, "Коврик для мыши", "Периферия", 14, 390),
            Product(9, "Адаптер", "Кабели", 11, 520),
            Product(10, "Колонки", "Аудио", 6, 2790),
        ]
        for product in examples:
            self.products[product.product_id] = product

    def all_products(self):
        return sorted(self.products.values())

    def find(self, text=""):
        text = text.casefold().strip()
        return [product for product in self.all_products()
                if text in product.name.casefold()
                or text in product.category.casefold()
                or text == str(product.product_id)]

    def add(self, name, category, quantity, price):
        next_id = max(self.products, default=0) + 1
        product = Product(next_id, name, category, quantity, price)
        self.products[product.product_id] = product
        self.save()
        return product

    def change_quantity(self, product_id, delta):
        product = self.products[int(product_id)]
        product.quantity = product.quantity + int(delta)
        self.save()
        return product

    def delete(self, product_id):
        del self.products[int(product_id)]
        self.save()

    def total_units(self):
        return sum(product.quantity for product in self.products.values())

    def total_value(self):
        return sum(product.quantity * product.price for product in self.products.values())

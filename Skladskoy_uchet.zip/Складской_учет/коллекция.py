class CustomMap:
    def __init__(self):
        self._items = []

    def __len__(self):
        return len(self._items)

    def __iter__(self):
        return (key for key, _ in self._items)

    def __contains__(self, key):
        return any(saved_key == key for saved_key, _ in self._items)

    def __getitem__(self, key):
        for saved_key, value in self._items:
            if saved_key == key:
                return value
        raise KeyError(key)

    def __setitem__(self, key, value):
        for index, (saved_key, _) in enumerate(self._items):
            if saved_key == key:
                self._items[index] = (key, value)
                return
        self._items.append((key, value))

    def __delitem__(self, key):
        for index, (saved_key, _) in enumerate(self._items):
            if saved_key == key:
                del self._items[index]
                return
        raise KeyError(key)

    def values(self):
        return [value for _, value in self._items]

    def clear(self):
        self._items.clear()
